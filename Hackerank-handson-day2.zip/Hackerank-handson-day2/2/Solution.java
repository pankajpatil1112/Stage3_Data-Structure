import java.io.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class Solution {

    /*
     * Complete the timeConversion function below.
     */
    static String timeConversion(String s) {
        /*
         * Write your code here.
         */
         
           int hh = Integer.parseInt(s.substring(0,2));
           int mm = Integer.parseInt(s.substring(3,5));
           int ss = Integer.parseInt(s.substring(6,8));
           String hhh, mmm, sss;
         if(s.endsWith("AM")){
            if(hh == 12){
                 if(mm < 9){
                 mmm = 0+Integer.toString(mm);
             }else{
                  mmm = Integer.toString(mm);
                }
             
             if(ss < 9){
                  sss = 0+Integer.toString(ss);
             }else{
                  sss = Integer.toString(ss);
                }
             
                return "00"+":"+mmm+":"+sss;
            }else{
                
                if(hh < 9){
                     hhh = 0+Integer.toString(hh);
                }else{
                    hhh = Integer.toString(hh);
                }
                 if(mm < 9){
                 mmm = 0+Integer.toString(mm);
             }else{
                  mmm = Integer.toString(mm);
                }
             
             if(ss < 9){
                  sss = 0+Integer.toString(ss);
             }else{
                  sss = Integer.toString(ss);
                }
                
                return hhh+":"+mmm+":"+sss;
            }
         }else{
             if(mm < 9){
                 mmm = 0+Integer.toString(mm);
             }else{
                  mmm = Integer.toString(mm);
             }
             if(ss < 9){
                sss = 0+Integer.toString(ss);
             }else{
                  sss = Integer.toString(ss);
             }
             if(hh == 12){
                return "12"+":"+mmm+":"+sss;
                }
             return (12+hh)+":"+mmm+":"+sss;
         }

    }

    private static final Scanner scan = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        String s = scan.nextLine();

        String result = timeConversion(s);

        bw.write(result);
        bw.newLine();

        bw.close();
    }
}
