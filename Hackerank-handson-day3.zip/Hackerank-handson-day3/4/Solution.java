import java.io.*;
import java.math.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;

public class Solution {

    /*
     * Complete the componentsInGraph function below.
     */
    static int[] componentsInGraph(int[][] gb,int n) {
            DC dc=new DC(gb,n);
            System.out.println(dc.m1);
            return dc.getRes();
    
    }
    static class DC{
        int arr[];
        boolean vis[];
        Map<Integer,Integer> m1=new HashMap<Integer,Integer>();
        DC(int gb[][],int n){
            arr=new int[2*n+1];
            vis=new boolean[arr.length];
            for(int i=0;i<arr.length;i++)arr[i]=i;
            for(int i=0;i<gb.length;i++)connect(gb[i][0]-1,gb[i][1]-1);
            make_map();

        }
        private int find(int p){
            vis[p]=true;
            return arr[p];
        }
        private void connect(int u,int v){
            int p=find(u);
            int q=find(v);
            if(p==q)return;
            for(int i=0;i<arr.length;i++){
                if(arr[i]==q)arr[i]=p;
            }        
        }
        private void make_map(){
            for(int i=0;i<arr.length;i++){
                if(vis[i]==false)continue;
                Integer temp=m1.get(arr[i]);
                if(temp==null)m1.put(arr[i],1);
                else m1.put(arr[i],temp+1);
            }
        }
        public int[] getRes(){
            int res[]=new int[2];
            int max=Integer.MIN_VALUE;
            int min=Integer.MAX_VALUE;
            for(int i:m1.values()){
                if(max<i)max=i;
                if(min>i)min=i;
            }
            res[0]=min;
            res[1]=max;
            return res;
        }
    }

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getenv("OUTPUT_PATH")));

        int n = Integer.parseInt(scanner.nextLine().trim());

        int[][] gb = new int[n][2];

        for (int gbRowItr = 0; gbRowItr < n; gbRowItr++) {
            String[] gbRowItems = scanner.nextLine().split(" ");

            for (int gbColumnItr = 0; gbColumnItr < 2; gbColumnItr++) {
                int gbItem = Integer.parseInt(gbRowItems[gbColumnItr].trim());
                gb[gbRowItr][gbColumnItr] = gbItem;
            }
        }

        int[] SPACE = componentsInGraph(gb,n);

        for (int SPACEItr = 0; SPACEItr < SPACE.length; SPACEItr++) {
            bufferedWriter.write(String.valueOf(SPACE[SPACEItr]));

            if (SPACEItr != SPACE.length - 1) {
                bufferedWriter.write(" ");
            }
        }

        bufferedWriter.newLine();

        bufferedWriter.close();
    }
}
